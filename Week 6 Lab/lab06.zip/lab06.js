
function problem1() {

    // this line will grab an integer from the input box.
    // but many problems will require string inputs!
    // you will have to change the code below accordingly.
    var a = parseInt(document.getElementById("a").value);
   
    var answer;
    // write your problem 1 code here
    
    // once you are done, write the result to the HTML page
    // as follows!
    document.getElementById("output1").innerHTML = answer; 
  
}

// Write more code below!
function problem2() {

}

function problem3() {

}

function problem4() {

}

function problem5() {

}

function problem6() {

}

